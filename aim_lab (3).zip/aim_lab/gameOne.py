import random
import tkinter as tk
from tkinter import messagebox

class NumberGuessingGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Number Guessing Game")
        self.root.geometry("400x350")
        self.root.configure(bg="#282c34")
        
        self.difficulty = tk.StringVar(value="medium")
        self.secret_number = random.randint(1, 100)
        self.guesses = []
        self.prev_guess = None
        self.best_score = None
        
        title_label = tk.Label(root, text="Guess the Number!", font=("Arial", 16, "bold"), fg="white", bg="#282c34")
        title_label.pack(pady=10)
        
        difficulty_frame = tk.Frame(root, bg="#282c34")
        difficulty_frame.pack()
        tk.Label(difficulty_frame, text="Choose Difficulty:", font=("Arial", 12), fg="white", bg="#282c34").pack(side=tk.LEFT)
        tk.OptionMenu(difficulty_frame, self.difficulty, "easy", "medium", "hard").pack(side=tk.RIGHT)
        
        self.entry = tk.Entry(root, font=("Arial", 14))
        self.entry.pack(pady=10)
        
        self.submit_button = tk.Button(root, text="Submit Guess", font=("Arial", 12, "bold"), bg="#61afef", fg="white", command=self.check_guess)
        self.submit_button.pack(pady=5)
        
        self.hint_label = tk.Label(root, text="Make your first guess!", font=("Arial", 12), fg="#98c379", bg="#282c34")
        self.hint_label.pack(pady=5)
        
        self.guess_history_label = tk.Label(root, text="Past Guesses: []", font=("Arial", 10), fg="#e5c07b", bg="#282c34")
        self.guess_history_label.pack()
        
        self.leaderboard_label = tk.Label(root, text="Best Score: N/A", font=("Arial", 10), fg="#d19a66", bg="#282c34")
        self.leaderboard_label.pack(pady=5)
    
    def animate_feedback(self, color):
        self.hint_label.config(fg=color)
        self.root.after(500, lambda: self.hint_label.config(fg="#98c379"))
    
    def get_hint(self, guess):
        if self.prev_guess is None:
            return "Make your first guess!"
        
        diff_now = abs(self.secret_number - guess)
        diff_prev = abs(self.secret_number - self.prev_guess)
        
        if self.difficulty.get() == 'easy':
            if diff_now == 0:
                return "Correct! You got it!"
            elif diff_now < diff_prev:
                return "You're getting warmer!"
            else:
                return "You're getting colder!"
        elif self.difficulty.get() == 'medium':
            if diff_now == 0:
                return "Correct! You got it!"
            elif diff_now < diff_prev:
                return "Warmer!"
            else:
                return "Colder!"
        else:  # Hard difficulty
            if diff_now == 0:
                return "Correct! You got it!"
            elif diff_now < diff_prev:
                return "Closer!"
            else:
                return "Farther!"
    
    def check_guess(self):
        try:
            guess = int(self.entry.get())
            if guess < 1 or guess > 100:
                messagebox.showerror("Error", "Guess must be between 1 and 100!")
                return
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number!")
            return
        
        self.guesses.append(guess)
        hint = self.get_hint(guess)
        self.hint_label.config(text=hint)
        self.guess_history_label.config(text=f"Past Guesses: {self.guesses}")
        
        if "warmer" in hint.lower() or "closer" in hint.lower():
            self.animate_feedback("#e5c07b")  # Yellow
        elif "colder" in hint.lower() or "farther" in hint.lower():
            self.animate_feedback("#e06c75")  # Red
        
        if guess == self.secret_number:
            attempts = len(self.guesses)
            messagebox.showinfo("Congratulations!", f"You found the number in {attempts} attempts!")
            
            if self.best_score is None or attempts < self.best_score:
                self.best_score = attempts
                self.leaderboard_label.config(text=f"Best Score: {self.best_score}")
            
            self.reset_game()
        
        self.prev_guess = guess
        self.entry.delete(0, tk.END)
    
    def reset_game(self):
        self.secret_number = random.randint(1, 100)
        self.guesses = []
        self.prev_guess = None
        self.hint_label.config(text="New game started! Guess the number.")
        self.guess_history_label.config(text="Past Guesses: []")
        self.entry.delete(0, tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    game = NumberGuessingGame(root)
    root.mainloop()
