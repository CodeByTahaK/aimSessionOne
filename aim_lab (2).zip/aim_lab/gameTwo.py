import pygame
import random

# Initialize pygame
pygame.init()

# Set up game window
width, height = 800, 600
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Pirate Ship Defender")

# Load assets (make sure to place the images in the same folder as your script)
background = pygame.image.load("images/sea_background.jpg")
pirate_ship_image = pygame.image.load("images/pirate_ship.jpg")

# Define colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

# Define font
font = pygame.font.SysFont("Arial", 24)

# Player class (Pirate Ship)
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.transform.scale(pirate_ship_image, (70, 70))  # Resizing the ship image
        self.rect = self.image.get_rect()
        self.rect.center = (width // 2, height - 70)
        self.speed = 5
    
    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < width:
            self.rect.x += self.speed

# Bullet class (Cannonballs)
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((10, 20))
        self.image.fill(RED)  # Red cannonball
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = 7
    
    def update(self):
        self.rect.y -= self.speed
        if self.rect.bottom < 0:
            self.kill()

# Enemy class (Pirate Ship enemies)
class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.transform.scale(pirate_ship_image, (70, 70))  # Same image for enemies
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, width - 70)
        self.rect.y = random.randint(-100, -40)
        self.speed = random.randint(2, 5)
    
    def update(self):
        self.rect.y += self.speed
        if self.rect.top > height:
            self.rect.x = random.randint(0, width - 70)
            self.rect.y = random.randint(-100, -40)

# Set up game groups
player_group = pygame.sprite.Group()
bullet_group = pygame.sprite.Group()
enemy_group = pygame.sprite.Group()

# Create player instance and add it to player group
player = Player()
player_group.add(player)

# Create enemies (all pirate ships)
for i in range(5):
    enemy = Enemy()
    enemy_group.add(enemy)

# Game variables
score = 0
enemy_passed = 0
running = True
game_over = False

# Game loop
clock = pygame.time.Clock()
while running:
    screen.blit(background, (0, 0))  # Draw background
    
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not game_over:
                # Shoot a cannonball
                bullet = Bullet(player.rect.centerx, player.rect.top)
                bullet_group.add(bullet)
    
    # Update game objects
    player_group.update()
    bullet_group.update()
    enemy_group.update()

    # Check for bullet collisions with enemies
    for bullet in bullet_group:
        enemy_hits = pygame.sprite.spritecollide(bullet, enemy_group, True)
        for hit in enemy_hits:
            bullet.kill()
            score += 10
            # Spawn new enemy
            new_enemy = Enemy()
            enemy_group.add(new_enemy)
    
    # Check for enemies passing the barrier
    for enemy in enemy_group:
        if enemy.rect.bottom > height - 50:  # Below the player's ship
            enemy_passed += 1
            enemy.kill()  # Remove the enemy that passed
            if enemy_passed > 50:
                game_over = True
    
    # Draw everything
    player_group.draw(screen)
    bullet_group.draw(screen)
    enemy_group.draw(screen)

    # Draw score and enemy passed
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_text, (10, 10))
    passed_text = font.render(f"Enemies Passed: {enemy_passed}", True, WHITE)
    screen.blit(passed_text, (10, 40))

    if game_over:
        game_over_text = font.render("You Lost! Press R to Restart", True, WHITE)
        screen.blit(game_over_text, (width // 2 - 140, height // 2 - 30))

    # Update the display
    pygame.display.flip()
    
    # Limit frames per second
    clock.tick(60)

# Close Pygame
pygame.quit()
