import pygame
import sounddevice as sd
import numpy as np
import time
import random

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
BACKGROUND_COLOR = (200, 255, 200)
FONT_COLOR = (0, 0, 0)
QUIET_THRESHOLD = 0.005  # Threshold to reward moderate silence (increased from previous)
LOUD_THRESHOLD = 0.01  # Threshold for loud noises (increased from previous)
DEBUG_MODE = True  # Set to True to print sound levels
DEVICE_INDEX = 5  # Set this to the correct microphone index if needed

# Create game window
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Quiet Time Game")

# Fonts
font = pygame.font.Font(None, 36)

# Score tracking
score = 0
start_time = time.time()

# Function to get microphone input
def get_sound_level():
    duration = 0.1  # Listen for 0.1 seconds
    sample_rate = 44100
    recording = sd.rec(int(duration * sample_rate), samplerate=sample_rate, channels=1, dtype='float32', device=DEVICE_INDEX)
    sd.wait()
    
    # Use peak amplitude instead of mean to detect noise better
    sound_level = np.max(np.abs(recording))
    
    if DEBUG_MODE:
        print(f"Sound Level: {sound_level}")
    return sound_level

# Game loop
running = True
last_point_time = time.time()  # Time to track when points were last added
session_duration = 600  # 10 minutes in seconds
consecutive_silence_time = 0  # Initialize consecutive silence time
motivational_messages = ["Keep it up!", "You're doing great!", "Stay focused!"]
while running:
    screen.fill(BACKGROUND_COLOR)
    
    # Get microphone input
    sound_level = get_sound_level()
    
    # Add a noise meter (color bar) to represent the current noise level
    noise_bar_width = int((sound_level / LOUD_THRESHOLD) * WIDTH)  # Scale noise level to screen width
    noise_bar_color = (255, 0, 0) if sound_level > LOUD_THRESHOLD else (255, 165, 0) if sound_level > QUIET_THRESHOLD else (0, 255, 0)
    pygame.draw.rect(screen, noise_bar_color, (0, HEIGHT - 50, noise_bar_width, 30))
    
    # Check if 5 seconds have passed for point increment
    current_time = time.time()
    if current_time - last_point_time >= 2:
        last_point_time = current_time  # Update the last point time
        
        # Adjust score based on thresholds
        if sound_level > LOUD_THRESHOLD:
            # Stop score increase and display loud message
            message = "Shh! You're too loud!"
            message_color = (255, 0, 0)
        elif sound_level > QUIET_THRESHOLD:
            # Penalize for moderate noise
            score -= 1
            message = "Quiet please!"
            message_color = (255, 165, 0)
        else:
            # Reward for silence
            score += 1
            message = "Good job!"
            message_color = (0, 255, 0)
    else:
        message = ""  # No message if no point change
    
    # Track consecutive silence time
    consecutive_silence_time = 0 if sound_level > QUIET_THRESHOLD else consecutive_silence_time + (current_time - last_point_time)
    if consecutive_silence_time >= 10:  # Reward after 10 seconds of silence
        reward_text = font.render("Great Job! You earned a star!", True, (255, 215, 0))
        screen.blit(reward_text, (WIDTH // 2 - 150, HEIGHT // 2 + 50))
    
    # Display score
    score_text = font.render(f"Score: {score}", True, FONT_COLOR)
    screen.blit(score_text, (WIDTH // 2 - 50, HEIGHT // 2 - 50))
    
    # Display message for loudness level
    if message:
        message_text = font.render(message, True, message_color)
        screen.blit(message_text, (WIDTH // 2 - 150, HEIGHT // 2))
    
    # Display remaining time
    remaining_time = max(0, session_duration - (current_time - start_time))
    timer_text = font.render(f"Time Left: {int(remaining_time)}s", True, FONT_COLOR)
    screen.blit(timer_text, (WIDTH // 2 - 50, HEIGHT // 2 - 100))
    if remaining_time <= 0:
        running = False  # End the game when time is up
    
    # Display motivational message every 30 seconds
    if current_time % 30 < 1:  # Show a message every 30 seconds
        message = random.choice(motivational_messages)
        motivational_text = font.render(message, True, (0, 0, 255))
        screen.blit(motivational_text, (WIDTH // 2 - 100, HEIGHT // 2 + 100))
    
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    pygame.display.flip()

pygame.quit()
