import sounddevice as sd
print(sd.query_devices())
